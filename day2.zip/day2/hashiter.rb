require 'pp'
$\ = "\n"
# iter

info = {hostname: 'ws1', domain: 'rootcap.in', 
		desc: 'web server', app: 'apache httpd', 
		version: 2.2}

info.each do |k, v| 
	printf "[%s] -> %s\n", k, v
end
print ''

print info.keys
print info.values

