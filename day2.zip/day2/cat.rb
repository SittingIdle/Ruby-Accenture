$\ = "\n"

begin
	print 1
	name
rescue NameError => e
		print e
ensure 
	print "am in sample"
end

