info = Hash::new() # {}
$\  = "\n"

print info
print info.length
print info.class