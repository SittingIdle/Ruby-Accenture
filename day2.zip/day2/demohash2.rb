require 'pp'

info = {hostname: 'ws1', domain: 'rootcap.in', 
		desc: 'web server', app: 'apache httpd', 
		version: 2.2}

$\  = "\n"

item_key = :hostname

if info.has_key? item_key   # validate 
	info[item_key] = 'ws9'  # update
end	

info[:arch] = 'x86_64'   # add 


# delete

value = info.delete :desc
print value
print ''
value = info.delete :app
print value
print ''


pp info
