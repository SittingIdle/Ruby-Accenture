require 'pp'
mat = [[1, 2, 3], 
	   [4, 5, 6], 
	   [7, 8 ,9]]

mat[1][1] = 'x'
mat[0].insert 1, [10]

mat.each do |row|
	row.each do |col|
		print col, "\t"
	end
	print "\n"
end

pp mat