require 'pp'
$\ = "\n"
# lookup 

info = {hostname: 'ws1', domain: 'rootcap.in', 
		desc: 'web server', app: 'apache httpd', 
		version: 2.2}

print info[:desc]
print info[:app]
print info[:verson]
print info.fetch(:version)
print info.fetch(:versionn, 'unknown-key')