items = [13, 15, 16, 17, 2, 18]
#=begin
# temp = []
# items.each {|item|  temp << (item.to_s 16)}
print temp
#=end


temp2 = items.map { |e|  e.to_s 16 }
#print temp2