# string vs symbols
$\ = "\n"
n = :pam
m = :pam
o = :pam

n = :pame
print n.__id__
print m.__id__
print o.__id__