require 'pp'

def group_words_by_count(word_count)
	group_by = {}

	word_count.each do |word, count|
		if group_by.has_key? count
			group_by[count] << word
		else
			group_by[count] = [word]
		end
	end
	return group_by
end

def get_word_count(txt_file)
	wc = {}

	File.open(txt_file) do |file|  
		file.each do |line|
			words = line.chomp!.split
			words.each do |word| 
				wc[word] = wc.fetch(word, 0) + 1 
			end
		end
	end
	return wc
end

tot = 0
wc = get_word_count 'messages.txt'
group_words_by_count(wc).each do |count, words| 
	printf "for the count %s we have %s words\n", count, words.length
	tot += words.length
end

print tot
