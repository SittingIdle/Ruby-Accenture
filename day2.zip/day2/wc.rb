require 'pp'

def get_word_count(txt_file)
	wc = {}

	File.open(txt_file) do |file|  
		file.each do |line|
			words = line.chomp!.split
			words.each do |word|
				if wc.has_key? word
					wc[word] += 1
				else
					wc[word] = 1
				end 
			end
		end
	end
	return wc
end

pp get_word_count 'messages.txt'	