$\ = "\n"
s = 'root,x:dummy,pass;0 0:root,/root;/bin/bash'
items = s.split /[,:; ]/
print items

items = s.split ':,;'
print items
print $$
