require 'pp'

content = []

File.open("passwd.txt") do |file|  
	file.each do |line|
		content << line.chomp!.split(':')
	end
end

content.sort! {|a, b| b[2].to_i <=> a[2].to_i}

content.each do |user_info|
	printf "%12s  %22s  %s\n", user_info[2], user_info[0], user_info[-1]
end
