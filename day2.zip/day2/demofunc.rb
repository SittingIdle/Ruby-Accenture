$\ = "\n"
print ARGV

def power(x, n)
 	return x ** n
end

print power ARGV[0].to_i, ARGV[1].to_i
print power 4, 2