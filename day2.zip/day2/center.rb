$\ = "\n"
def center(str_content, width, fill_char)
	n = (width - str_content.length) / 2 
	sprintf "%s%s%s", fill_char * n, str_content, fill_char * n
end

print center "ruby", 8, '-'	  
# --ruby--
print 'ruby'.center(9, '-')
#print 'ruby'.center(8)