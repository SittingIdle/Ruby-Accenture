def get_user_list(data_file, target_file)
	user_list = []

	File.open(data_file) do |file|  
		file.each do |line|
			user_list << line.split(':')[0]
		end
	end

	File.open(target_file, "w") do |fw| 
		user_list.sort!.each_index do |line_no|
			content = sprintf "%6s  %s\n", line_no + 1, user_list[line_no]
			print content
			fw.write(content)			
		end
	end
end

get_user_list 'passwd.txt', 'passwd.dat'
