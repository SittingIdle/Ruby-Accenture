s = "the python and the perl scritping"
$\ = "\n"

if s =~ /P.+?N/i
	print "got a match"
	print "matched :", $&
	printf "before :|%s|\n", $`
	printf "after :|%s|\n", $'
	print "failed to match"
end		