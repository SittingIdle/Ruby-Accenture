s = "a sample	text in the ruby"

s2 = s.gsub(/\s/, ',')
print s2