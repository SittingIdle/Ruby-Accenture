require 'pp'
$\ = "\n"

info = {hostname: 'ws1', domain: 'rootcap.in', 
		desc: 'web server', app: 'apache httpd', 
		version: 2.2}

#info_keys = [:version, :app, :desc]

info.keys.each do |item_key|
	print item_key, ' -> ', info[item_key] if info.has_key? item_key
end

