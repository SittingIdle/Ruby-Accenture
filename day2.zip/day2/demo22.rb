items = (1..59).to_a
=begin
temp = []

items.each do |e|  
	if e % 7 == 0
		temp << e
	end
end
print temp
=end

# temp2 = items.select {|e| e % 7 == 0 }
temp2 = items.reject {|e| e % 7 == 0 }
print temp2
