def grep_me(pattern, file_name)
	File.open(file_name) do |file|  
		file.each do |line|
			print line if line =~ /#{pattern}/i
		end
	end
end

# grep_me 'login$', 'passwd.txt'
# grep_me 'b.t', 'data.dat'
# grep_me 'b(a|e|i)t', 'data.dat'
#grep_me 'b[^aeiou]t', 'data.dat'
#grep_me '\b[789][0-9]{9}\b', 'phpne.txt'
grep_me '\$5\.12', 'apple.txt'
