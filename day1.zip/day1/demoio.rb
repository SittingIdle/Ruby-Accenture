# demo IO
print "enter the name :"
name = gets.chomp

print "enter the city :"
city = gets.chomp

print "enter the postal zip:"
zip_code = gets.chomp

$\ = "\n"

print "name : #{name}"
print "city : #{city}"
print zip_code.to_i
print zip_code.to_f.class
print zip_code.to_i.class  # type of an object
