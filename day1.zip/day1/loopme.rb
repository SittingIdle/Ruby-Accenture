i = 10

while i <= 20
	printf "%6s %6d %6f %6x %6o %6b\n", i, i, i, i, i, i
	i += 1
end