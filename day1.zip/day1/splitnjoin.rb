str_content = 'root:x:0:0:root:/root:/bin/bash'
items = str_content.split ':'
$\ = "\n"

print items
print str_content.split(':')[0]


delimiter = ';'
s2 = items.join(delimiter)
print ''


