fp = File.open('passwd.txt')

fp.each {|line| printf "%6s  %s", $., line}
fp.close