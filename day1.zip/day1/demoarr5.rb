$\ = "\n"
items = ['pam', 'matz', 'ruby',  'gems', 'amanda', 'kim', 'joe']

sorted = items.sort do |a, b| 
	b <=> a
end

print sorted

