name = 'accenture'
city = 'gurgaon'
$\ = "\n"  # ORS

print "name : #{name}"
print "city : #{city}"
