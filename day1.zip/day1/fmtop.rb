name, age, gender = 'sara', 4, 'female'
printf "|%s|+%s|%s|\n", name, age, gender
printf "|%22s|%5s|%16s|\n", name, age, gender
printf "|%-22s|%-5s|%-16s|\n", name, age, gender