i = 1
$\ = "\n"

begin
	if i == 1
		print "one"
	elsif i == 2
		print 'ii'
	elsif i == 5
		i += 1
		redo
	elsif i == 7
		break
	else
		print i
	end 	
	i += 1
end until i > 10
