#slicing
$\ = "\n"
s = "perlandpython"
print s[0, 4]
print s[0..3]
print s[3, 4]
