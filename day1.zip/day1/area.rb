print "enter the radius :"
radius = gets.to_f
area = Math::PI * (radius ** 2)  
content = sprintf "radius : %f\narea : %.3f", radius, area
print content.upcase