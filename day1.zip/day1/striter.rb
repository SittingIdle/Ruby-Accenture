#slicing
$\ = "\n"
s = <<DOC
perl and python
DOC

for item_char in s.each_char
	printf "[%s] -> %s\n", item_char, item_char.ord
end
