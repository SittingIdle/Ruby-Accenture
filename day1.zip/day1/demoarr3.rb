items = ['pam', 12.12, 123, 'matz', 'ruby', 'gems']
$\ = "\n"

print items
value = items.shift
print value
print ''
value = items.pop
print value
print ''
print items
value = items.delete_at -2
print value
print ''
print items
