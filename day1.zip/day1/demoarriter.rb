items = ["root", "x", "0", "0", "root", "/root", "/bin/bash"]
$\ = "\n"

items.each {|item|  print item}
print ""

items.each_index {|index|  print index, ' -> ', items[index]}

