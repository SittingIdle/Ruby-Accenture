=begin 
op = `dir`
print op
defined?
=end
$\ = "\n"
name = "peter"
@item = 12.12
@@class_var = 'item'
print (defined? items)
print defined? name
print defined? $\
print defined? @@class_var
print defined? @item
