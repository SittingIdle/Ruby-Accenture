def compute_bill(units)
	amount = 0

	if units <= 100
		amount = units
	elsif units <= 200
		amount= units * 1.5
	elsif units <= 500
		amount = 400 + (units - 200) * 3	
	elsif units > 500
		amount = 1800 + (units - 500) * 5.75
	end
	return amount

end

print "enter the units :"
consumed_units = gets.to_i
printf "billable : %.2f\n", compute_bill(consumed_units)
