$\ = "\n"
# version = '2.11.23'
=begin
content = "c:\\temp\\neo\\blame\\folder99\\#{version}\\template.txt"
print content

print ''

content = 'c:\temp\neo\blame\folder99\#{version}\template.txt'
print content

print version + version 
print version * 3
print version.length
print version.size

=end