$\ = "\n"
items = ['pam', 12.12, 123, 'matz', 'ruby', 'gems']
reversed = items.reverse
reversed.push 100
print reversed
print items

# exit 0
print ''
items.reverse!  #inplace edit 
print items