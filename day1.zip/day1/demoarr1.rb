items = Array.new(10, 'matz') # []
$\ = "\n"
print items
print items.class
print items.size