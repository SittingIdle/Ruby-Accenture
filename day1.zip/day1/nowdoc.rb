# heredoc
char = 'x'

content = <<DOC
     1 
    2 2
   3 #{char} 3
    4\t4
     4
DOC
print content

content = <<'ABC'
     1 
    2 2
   3 #{char} 3
    4\t4
     4
ABC

print content