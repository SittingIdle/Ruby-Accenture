items = ['pam', 12.12, 123, 'matz', 'ruby', 'gems']
$\ = "\n"

items[-3] = 'larry'
items.unshift 'hp'
items.push 'ny'
print items.index 123

# items.insert items.index(123), 'acceture'
print items