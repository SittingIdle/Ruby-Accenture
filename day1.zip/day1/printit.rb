$\ = "\n"

5.times { print "ruby"}