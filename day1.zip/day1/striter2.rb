#slicing
$\ = "\n"
s = 'perl and python'
path = "anything"

# path.each_char {|char|	printf "[%s] -> %s\n", char, char.ord }

path.each_char do |char| 
	printf "[%s] -> %s\n", char, char.ord 
end	

